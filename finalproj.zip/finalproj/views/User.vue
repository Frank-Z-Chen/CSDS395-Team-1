<template>
    <div>
        user testing
    </div>
</template>

<script>
    export default{
        name: 'User',
        data(){
            return {}
        }
    }
</script>
